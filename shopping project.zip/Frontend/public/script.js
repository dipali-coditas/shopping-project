fetch('http://localhost:8000/get_data')
  .then(res => res.json())
  .then(data => {

    let output = '<div>';

    data.forEach(product => {
      output += `
        <div>

          <img src="${product.img}" width="100">
          <h3>${product.name}</h3>
          <p>${product.desc}</p>
          <b>$${product.price}</b>
        </div>
      `;
    });

    output += '</div>';

    document.getElementById('products').innerHTML = output;

  })
  .catch(err => console.log(err));